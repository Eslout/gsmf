#!/bin/bash

cd /usr/src/gsmevil2
source venv/bin/activate
python3.8 GsmEvil.py
