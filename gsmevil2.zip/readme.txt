GsmEvil2 For DragonOS FocalX

Step 1: Extract 'venv' folder , 'gsmevil2.sh' and 'start_gsmevil2.sh' bash scripts to your /home/*username*/ directory.

Step 2: Make both bash scripts executable with this commmand (run in terminal): 

chmod +x gsmevil2.sh && chmod +x start_gsmevil2.sh

Step 3: Double click on 'start_gsmevil2.sh' to run GsmEvil2.

Step 4: Open web browser (e.g Firefox), type 'localhost' into the address bar and press enter.

Step 5: Enjoy :)

**** DO NOT DELETE the bash script 'gsmevil2.sh' or you won't be able to start GsmEvil2!!! ****

Explanation: 
GSMEvil2 used to work in DragonOS Focal. But in FocalX, it must be run inside a virtual Python 3.8 environment. The files inside this archive and the instructions witten above will enable you to run GsmEvil2 on the latest versions of DragonOS FocalX without too many headaches :) 

Rob VK8FOES
 
