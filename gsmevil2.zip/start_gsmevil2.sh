#!/bin/bash

sudo qterminal -e ~/gsmevil2.sh
